describe('Battleship Game', () => {
  beforeEach(() => {
    cy.visit('http://localhost/statki/index.php'); 
    cy.wait(2000); 
  });

  it('should have link to register page', () => {
    cy.get('a[href="register.php"]').should('exist').and('contain', 'Register');
  });

  it('should have image background', () => {
    cy.get('body').should('have.css', 'background-image').and('include', 'dT9rXxAkc.png');
  });

  it('should have correct text color', () => {
    cy.get('body').should('have.css', 'color').and('eq', 'rgb(0, 0, 139)');
  });

  it('should have centered alignment for heading', () => {
    cy.get('h1').should('have.css', 'text-align').and('eq', 'center');
  });

  it('should have visible input box', () => {
    cy.get('#inputBox').should('be.visible');
  });

  it('should display the login form', () => {
    cy.get('form').should('exist');
    cy.get('input[name="username"]').should('exist');
    cy.get('input[name="password"]').should('exist');
    cy.get('button[type="submit"]').should('exist').and('contain', 'Unlock');
  });

  it('should display registration link', () => {
    cy.get('a[href="register.php"]').should('exist').and('contain', 'Register');
  });

  it('should display error message for incorrect username', () => {
    cy.get('input[name="username"]').type('invalid_username');
    cy.get('input[name="password"]').type('password');
    cy.get('button[type="submit"]').click();
    cy.get('#error-message').should('contain', 'Username does not exist.');
  });

  it('should not redirect to game page after unsuccessful login', () => {
    cy.get('input[name="username"]').type('invalid_username');
    cy.get('input[name="password"]').type('invalid_password');
    cy.get('button[type="submit"]').click();
    cy.url().should('not.include', 'statki.php');
  });

  it('should have responsive design for different screen sizes', () => {
  
  });

  it('should have proper accessibility attributes', () => {

  });

  it('should have appropriate title', () => {
    cy.title().should('eq', 'Battleship Game');
  });

});
