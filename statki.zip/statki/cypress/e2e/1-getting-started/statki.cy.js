describe('Battleship Game', () => {
    beforeEach(() => {
      cy.visit('http://localhost/statki/statki.php'); 
      cy.wait(2000);
    });
  
    it('should have link to register page', () => {
      cy.get('a[href="logout.php"]').should('exist').and('contain', 'Logout');
    });
  
    it('should have title "Statki"', () => {
      cy.get('h1.tyt').should('exist').and('contain', 'Statki');
    });
  
    it('should have game status', () => {
      cy.get('.status').should('exist').and('contain', 'Status');
    });
  
    it('should have player and CPU boards', () => {
      cy.get('#playerBoard').should('exist');
      cy.get('#cpuBoard').should('exist');
    });
    it('should have clickable cells on CPU board', () => {
        cy.get('#cpuBoard .cell').first().click();
        cy.get('.status').should('contain', 'CPU ships left');
      });
  });
  