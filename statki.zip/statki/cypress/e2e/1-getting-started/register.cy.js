describe('Registration Page', () => {
    beforeEach(() => {
      cy.visit('http://localhost/statki/register.php');
      cy.wait(2000); 
    });
  
    it('should have a title "Register"', () => {
      cy.title().should('eq', 'Register');
    });
  
    it('should have a form with input fields for username, password, and repeat password', () => {
      cy.get('form').should('exist');
      cy.get('input[name="username"]').should('exist').should('have.attr', 'required');
      cy.get('input[name="password"]').should('exist').should('have.attr', 'required');
      cy.get('input[name="repeat_password"]').should('exist').should('have.attr', 'required');
    });
  
    it('should display an error message if passwords do not match', () => {
      cy.get('input[name="username"]').type('test_user');
      cy.get('input[name="password"]').type('password');
      cy.get('input[name="repeat_password"]').type('different_password');
      cy.get('button[type="submit"]').click();
      cy.contains('Passwords do not match.').should('exist');
    });
  
    it('should display success message upon successful registration', () => {
      const username = 'new_user_' + Math.floor(Math.random() * 1000);
      cy.get('input[name="username"]').type(username);
      cy.get('input[name="password"]').type('password');
      cy.get('input[name="repeat_password"]').type('password');
      cy.get('button[type="submit"]').click();
      cy.contains('User registered successfully.').should('exist');
    });
  
    it('should return to main page upon double clicking the Register button', () => {
      cy.get('button[type="submit"]').dblclick();
      cy.url().should('include', 'index.php');
    });
  });
  